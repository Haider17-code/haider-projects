
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TaxCalculatorForm from "@/components/TaxCalculatorForm";
import TaxSummary from "@/components/TaxSummary";
import TaxHistory from "@/components/TaxHistory";
import { calculateTax } from "@/utils/taxCalculator";
import { TaxFormData, TaxSummaryData, HistoryEntry } from "@/types/tax";
import { toast } from "@/components/ui/sonner";

const Index = () => {
  const [activeTab, setActiveTab] = useState("calculator");
  const [taxSummary, setTaxSummary] = useState<TaxSummaryData | null>(null);
  const [formData, setFormData] = useState<TaxFormData | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // Load history from localStorage on initial render
  useEffect(() => {
    const savedHistory = localStorage.getItem("taxCalculationHistory");
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (error) {
        console.error("Failed to parse history from localStorage:", error);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("taxCalculationHistory", JSON.stringify(history));
  }, [history]);

  const handleCalculate = (formData: TaxFormData) => {
    setFormData(formData);
    const summary = calculateTax(formData);
    setTaxSummary(summary);
    setActiveTab("summary");
  };

  const handleSaveToHistory = () => {
    if (taxSummary) {
      const newEntry: HistoryEntry = {
        id: Date.now().toString(),
        date: new Date(),
        summary: { ...taxSummary }
      };
      
      setHistory(prevHistory => [newEntry, ...prevHistory]);
      toast.success("Calculation saved to history");
    }
  };

  const handleLoadHistory = (entry: HistoryEntry) => {
    setTaxSummary(entry.summary);
    setActiveTab("summary");
    toast.success("Historical calculation loaded");
  };

  const handleClearHistory = () => {
    setHistory([]);
    toast.success("History cleared");
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Indian Income Tax Calculator
          </h1>
          <p className="mt-3 text-xl text-gray-600">
            Financial Year 2024-25 (Assessment Year 2025-26)
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Tax Calculator</CardTitle>
            <CardDescription>
              Enter your details below to calculate your income tax liability
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="calculator">Calculator</TabsTrigger>
                <TabsTrigger value="summary" disabled={!taxSummary}>
                  Tax Summary
                </TabsTrigger>
                <TabsTrigger value="history">
                  History
                </TabsTrigger>
              </TabsList>
              <TabsContent value="calculator">
                <TaxCalculatorForm onCalculate={handleCalculate} initialValues={formData} />
              </TabsContent>
              <TabsContent value="summary">
                {taxSummary && <TaxSummary data={taxSummary} onSaveToHistory={handleSaveToHistory} />}
              </TabsContent>
              <TabsContent value="history">
                <TaxHistory 
                  history={history} 
                  onLoadHistory={handleLoadHistory}
                  onClearHistory={handleClearHistory}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;
