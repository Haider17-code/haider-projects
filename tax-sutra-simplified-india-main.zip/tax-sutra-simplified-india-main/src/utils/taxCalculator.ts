
import { TaxFormData, TaxSummaryData, TaxSlabInfo } from "@/types/tax";

/**
 * Old regime tax slabs for FY 2024-25
 */
const OLD_REGIME_SLABS = [
  { min: 0, max: 250000, rate: 0 },
  { min: 250000, max: 500000, rate: 0.05 }, // 5%
  { min: 500000, max: 1000000, rate: 0.2 }, // 20%
  { min: 1000000, max: Infinity, rate: 0.3 }, // 30%
];

/**
 * New regime tax slabs for FY 2024-25
 */
const NEW_REGIME_SLABS = [
  { min: 0, max: 300000, rate: 0 },
  { min: 300000, max: 600000, rate: 0.05 }, // 5%
  { min: 600000, max: 900000, rate: 0.1 }, // 10%
  { min: 900000, max: 1200000, rate: 0.15 }, // 15%
  { min: 1200000, max: 1500000, rate: 0.2 }, // 20%
  { min: 1500000, max: Infinity, rate: 0.3 }, // 30%
];

/**
 * Maximum deduction limits
 */
const DEDUCTION_LIMITS = {
  section80C: 150000, // ₹1,50,000
  section80D: 25000, // ₹25,000
};

/**
 * Calculate taxes based on the provided form data
 */
export const calculateTax = (formData: TaxFormData): TaxSummaryData => {
  const { annualSalary, regime, section80C, section80D, hra, otherDeductions } = formData;

  // Calculate deductions (only applicable for old regime)
  const totalDeductions = regime === "old" 
    ? Math.min(section80C, DEDUCTION_LIMITS.section80C) + 
      Math.min(section80D, DEDUCTION_LIMITS.section80D) + 
      hra + 
      otherDeductions
    : 0;

  // Calculate taxable income
  const taxableIncome = Math.max(0, annualSalary - totalDeductions);

  // Calculate tax based on regime
  const slabs = regime === "old" ? OLD_REGIME_SLABS : NEW_REGIME_SLABS;
  let tax = 0;
  const taxBreakdown: TaxSlabInfo[] = [];

  // Calculate tax slab by slab
  let remainingIncome = taxableIncome;
  for (const slab of slabs) {
    if (remainingIncome <= 0) break;

    const slabAmount = Math.min(remainingIncome, slab.max - slab.min);
    const slabTax = slabAmount * slab.rate;
    
    if (slabTax > 0) {
      taxBreakdown.push({
        slab: `₹${slab.min.toLocaleString('en-IN')} to ₹${
          slab.max === Infinity ? "∞" : slab.max.toLocaleString('en-IN')
        } (${slab.rate * 100}%)`,
        tax: slabTax
      });
      tax += slabTax;
    }
    
    remainingIncome -= slabAmount;
  }

  // Apply rebate under section 87A for new regime (if applicable)
  if (regime === "new" && taxableIncome <= 700000 && tax > 0) {
    const rebate = Math.min(tax, 25000);
    tax -= rebate;
    taxBreakdown.push({
      slab: "Rebate u/s 87A",
      tax: -rebate
    });
  }

  // Apply rebate under section 87A for old regime (if applicable)
  if (regime === "old" && taxableIncome <= 500000 && tax > 0) {
    const rebate = Math.min(tax, 12500);
    tax -= rebate;
    taxBreakdown.push({
      slab: "Rebate u/s 87A",
      tax: -rebate
    });
  }

  // Add health and education cess (4%)
  const cessAmount = tax * 0.04;
  tax += cessAmount;

  // Calculate monthly in-hand salary after tax
  const totalAnnualTax = Math.round(tax);
  const annualInHandSalary = annualSalary - totalAnnualTax;
  const monthlyInHandSalary = Math.round(annualInHandSalary / 12);

  return {
    grossIncome: annualSalary,
    totalDeductions,
    taxableIncome,
    taxPayable: totalAnnualTax,
    monthlyInHandSalary,
    regime,
    taxBreakdown,
    cessAmount: Math.round(cessAmount)
  };
};
