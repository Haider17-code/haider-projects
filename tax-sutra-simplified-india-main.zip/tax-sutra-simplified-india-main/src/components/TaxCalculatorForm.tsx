
import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { TaxFormData } from "@/types/tax";
import { toast } from "@/components/ui/sonner";

const formSchema = z.object({
  annualSalary: z.coerce.number().min(0, "Salary cannot be negative"),
  regime: z.enum(["old", "new"], {
    required_error: "Please select a tax regime",
  }),
  section80C: z.coerce.number().min(0).default(0),
  section80D: z.coerce.number().min(0).default(0),
  hra: z.coerce.number().min(0).default(0),
  otherDeductions: z.coerce.number().min(0).default(0),
});

interface TaxCalculatorFormProps {
  onCalculate: (data: TaxFormData) => void;
  initialValues?: TaxFormData | null;
}

const TaxCalculatorForm = ({ onCalculate, initialValues = null }: TaxCalculatorFormProps) => {
  const [showOldRegimeFields, setShowOldRegimeFields] = useState(true);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: initialValues || {
      annualSalary: 0,
      regime: "old",
      section80C: 0,
      section80D: 0,
      hra: 0,
      otherDeductions: 0,
    },
  });

  // Update form when initialValues change
  useEffect(() => {
    if (initialValues) {
      form.reset(initialValues);
      setShowOldRegimeFields(initialValues.regime === "old");
    }
  }, [initialValues, form]);

  function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      onCalculate(values as TaxFormData);
      toast.success("Tax calculated successfully!");
    } catch (error) {
      toast.error("Failed to calculate tax. Please check your inputs.");
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="annualSalary"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Annual Salary (₹)</FormLabel>
              <FormControl>
                <Input type="number" placeholder="0" {...field} />
              </FormControl>
              <FormDescription>
                Enter your total annual salary before any deductions
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="regime"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tax Regime</FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={(value) => {
                    field.onChange(value);
                    setShowOldRegimeFields(value === "old");
                  }}
                  defaultValue={field.value}
                  className="flex flex-col space-y-1"
                >
                  <FormItem className="flex items-center space-x-3 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="old" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      Old Regime (with deductions)
                    </FormLabel>
                  </FormItem>
                  <FormItem className="flex items-center space-x-3 space-y-0">
                    <FormControl>
                      <RadioGroupItem value="new" />
                    </FormControl>
                    <FormLabel className="font-normal">
                      New Regime (lower rates, no deductions)
                    </FormLabel>
                  </FormItem>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {showOldRegimeFields && (
          <>
            <Separator className="my-4" />
            <h3 className="text-lg font-medium">Deductions (Old Regime)</h3>
            <div className="grid gap-6 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="section80C"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Section 80C (₹)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      PPF, ELSS, LIC, etc. (Max: ₹1,50,000)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="section80D"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Section 80D (₹)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      Health Insurance Premium (Max: ₹25,000)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="hra"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>HRA Exemption (₹)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      House Rent Allowance exemption
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="otherDeductions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Other Deductions (₹)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" {...field} />
                    </FormControl>
                    <FormDescription>
                      Other applicable deductions
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </>
        )}

        <Button type="submit" className="w-full">
          Calculate Tax
        </Button>
      </form>
    </Form>
  );
};

export default TaxCalculatorForm;
