
import { useState } from "react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { HistoryEntry } from "@/types/tax";
import { IndianRupee } from "lucide-react";
import { format } from "date-fns";

interface TaxHistoryProps {
  history: HistoryEntry[];
  onLoadHistory: (entry: HistoryEntry) => void;
  onClearHistory: () => void;
}

const TaxHistory = ({ history, onLoadHistory, onClearHistory }: TaxHistoryProps) => {
  const [expandedEntryId, setExpandedEntryId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    if (expandedEntryId === id) {
      setExpandedEntryId(null);
    } else {
      setExpandedEntryId(id);
    }
  };

  if (history.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No calculation history yet.</p>
        <p className="text-gray-500 text-sm mt-1">
          Your tax calculations will appear here once you save them.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Calculation History</h3>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onClearHistory}
        >
          Clear All
        </Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Income</TableHead>
              <TableHead>Regime</TableHead>
              <TableHead>Tax</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {history.map((entry) => (
              <>
                <TableRow key={entry.id} className="cursor-pointer hover:bg-gray-50" onClick={() => toggleExpand(entry.id)}>
                  <TableCell>{format(new Date(entry.date), "dd MMM yyyy, HH:mm")}</TableCell>
                  <TableCell>₹{entry.summary.grossIncome.toLocaleString("en-IN")}</TableCell>
                  <TableCell>{entry.summary.regime === "old" ? "Old" : "New"}</TableCell>
                  <TableCell>₹{entry.summary.taxPayable.toLocaleString("en-IN")}</TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={(e) => {
                        e.stopPropagation();
                        onLoadHistory(entry);
                      }}
                    >
                      Load
                    </Button>
                  </TableCell>
                </TableRow>
                {expandedEntryId === entry.id && (
                  <TableRow>
                    <TableCell colSpan={5} className="bg-gray-50 p-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-medium">Monthly In-Hand:</p>
                          <p className="flex items-center">
                            <IndianRupee className="h-3 w-3 mr-1" />
                            {entry.summary.monthlyInHandSalary.toLocaleString("en-IN")}
                          </p>
                        </div>
                        <div>
                          <p className="font-medium">Total Deductions:</p>
                          <p>₹{entry.summary.totalDeductions.toLocaleString("en-IN")}</p>
                        </div>
                        <div>
                          <p className="font-medium">Taxable Income:</p>
                          <p>₹{entry.summary.taxableIncome.toLocaleString("en-IN")}</p>
                        </div>
                        <div>
                          <p className="font-medium">Health & Education Cess:</p>
                          <p>₹{entry.summary.cessAmount.toLocaleString("en-IN")}</p>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default TaxHistory;
