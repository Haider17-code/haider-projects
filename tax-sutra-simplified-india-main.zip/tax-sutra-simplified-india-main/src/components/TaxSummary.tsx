
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TaxSummaryData } from "@/types/tax";
import { IndianRupee, Save } from "lucide-react";

interface TaxSummaryProps {
  data: TaxSummaryData;
  onSaveToHistory: () => void;
}

const TaxSummary = ({ data, onSaveToHistory }: TaxSummaryProps) => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Tax Summary</h3>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onSaveToHistory}
          className="flex items-center gap-2"
        >
          <Save className="h-4 w-4" /> Save to History
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <SummaryCard title="Gross Annual Income" value={data.grossIncome} />
        <SummaryCard title="Total Deductions" value={data.totalDeductions} />
        <SummaryCard title="Taxable Income" value={data.taxableIncome} />
        <SummaryCard
          title="Tax Payable"
          value={data.taxPayable}
          highlighted={true}
        />
      </div>
      
      <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-green-800">Monthly In-Hand Salary</h3>
          <p className="text-sm text-green-600">After tax deductions</p>
        </div>
        <div className="flex items-center text-2xl font-bold text-green-700">
          <IndianRupee className="h-5 w-5 mr-1" />
          {data.monthlyInHandSalary.toLocaleString('en-IN')}
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="text-lg font-medium mb-2">Tax Regime</h3>
        <p className="text-gray-700">
          {data.regime === "old"
            ? "Old Regime (with deductions)"
            : "New Regime (lower rates, no deductions)"}
        </p>
        
        <h3 className="text-lg font-medium mt-4 mb-2">Tax Breakdown</h3>
        <div className="space-y-2">
          {data.taxBreakdown.map((item, index) => (
            <div key={index} className="flex justify-between text-sm">
              <span>{item.slab}</span>
              <span>₹{item.tax.toLocaleString('en-IN')}</span>
            </div>
          ))}
          {data.cessAmount > 0 && (
            <div className="flex justify-between text-sm">
              <span>Health & Education Cess (4%)</span>
              <span>₹{data.cessAmount.toLocaleString('en-IN')}</span>
            </div>
          )}
          <div className="flex justify-between font-medium pt-2 border-t">
            <span>Total</span>
            <span>₹{data.taxPayable.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const SummaryCard = ({
  title,
  value,
  highlighted = false,
}: {
  title: string;
  value: number;
  highlighted?: boolean;
}) => {
  return (
    <Card className={highlighted ? "border-primary" : ""}>
      <CardContent className="p-4">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p
          className={`text-2xl font-semibold mt-1 ${
            highlighted ? "text-primary" : "text-gray-900"
          }`}
        >
          ₹{value.toLocaleString("en-IN")}
        </p>
      </CardContent>
    </Card>
  );
};

export default TaxSummary;
