
export interface TaxFormData {
  annualSalary: number;
  regime: "old" | "new";
  section80C: number;
  section80D: number;
  hra: number;
  otherDeductions: number;
}

export interface TaxSlabInfo {
  slab: string;
  tax: number;
}

export interface TaxSummaryData {
  grossIncome: number;
  totalDeductions: number;
  taxableIncome: number;
  taxPayable: number;
  monthlyInHandSalary: number;
  regime: "old" | "new";
  taxBreakdown: TaxSlabInfo[];
  cessAmount: number;
}

export interface HistoryEntry {
  id: string;
  date: Date;
  summary: TaxSummaryData;
}
